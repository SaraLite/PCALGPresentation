Autores:
    Álvaro Huertas García 
    Diego Mañanes Cayero
    Alejandro Martín Muñoz 
    Sara Dorado Alfaro

El trabajo se ha repartido de forma equitativa entre los cuatro componentes del grupo: tanto la búsqueda bibliográfica, la selección de la información como la presentación final. Escribirnos en caso de requerir más información.